// ТехноМаркет — Main JS

document.addEventListener('DOMContentLoaded', function () {

    const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content;

    // ---- Cart badge update ----
    function updateCartBadge(count) {
        const badge = document.getElementById('cart-badge');
        if (!badge) return;
        badge.textContent = count;
        if (count > 0) {
            badge.classList.remove('d-none');
        } else {
            badge.classList.add('d-none');
        }
    }

    // ---- Show toast ----
    function showToast(id) {
        const el = document.getElementById(id);
        if (!el) return;
        const toast = new bootstrap.Toast(el, { delay: 3000 });
        toast.show();
    }

    // ---- Add to cart (catalog page) ----
    document.querySelectorAll('.add-to-cart').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const id = this.dataset.id;
            fetch('/cart/add/' + id, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    updateCartBadge(data.cart_count);
                    showToast('cartToast');
                } else {
                    const errEl = document.getElementById('cartToastErrorMsg');
                    if (errEl) errEl.textContent = data.error || 'Ошибка';
                    showToast('cartToastError');
                }
            })
            .catch(() => showToast('cartToastError'));
        });
    });

    // ---- Add to cart (product detail page) ----
    const addDetailBtn = document.querySelector('.add-to-cart-detail');
    if (addDetailBtn) {
        addDetailBtn.addEventListener('click', function () {
            const id = this.dataset.id;
            fetch('/cart/add/' + id, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    updateCartBadge(data.cart_count);
                    showToast('cartToast');
                } else {
                    const errEl = document.getElementById('cartToastErrorMsg');
                    if (errEl) errEl.textContent = data.error || 'Ошибка';
                    showToast('cartToastError');
                }
            });
        });
    }

    // ---- Cart quantity controls ----
    document.querySelectorAll('.cart-qty-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const id     = this.dataset.id;
            const action = this.dataset.action;
            const price  = parseFloat(this.closest('tr').querySelector('td:nth-child(2)').textContent.replace(/\s/g, '').replace('₽', ''));

            fetch('/cart/update/' + id, {
                method: 'POST',
                headers: {
                    'X-CSRF-TOKEN': csrfToken,
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                },
                body: JSON.stringify({ action }),
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    updateCartBadge(data.cart_count);
                    // Reload page to recalculate totals
                    location.reload();
                } else {
                    const errEl = document.getElementById('cartErrorMsg');
                    if (errEl) errEl.textContent = data.error || 'Ошибка';
                    showToast('cartErrorToast');
                }
            });
        });
    });

    // ---- Client-side registration validation ----
    const regForm = document.getElementById('register-form');
    if (regForm) {
        const cyrillicFields = [
            { field: regForm.querySelector('[name="name"]'),       label: 'Имя' },
            { field: regForm.querySelector('[name="surname"]'),    label: 'Фамилия' },
            { field: regForm.querySelector('[name="patronymic"]'), label: 'Отчество', optional: true },
        ];

        const loginField = regForm.querySelector('[name="login"]');

        regForm.addEventListener('submit', function (e) {
            let valid = true;

            cyrillicFields.forEach(function ({ field, label, optional }) {
                if (!field) return;
                const val = field.value.trim();
                if (optional && val === '') return;
                if (!/^[а-яёА-ЯЁ\s\-]+$/.test(val)) {
                    field.classList.add('is-invalid');
                    let fb = field.nextElementSibling;
                    if (!fb || !fb.classList.contains('invalid-feedback')) {
                        fb = document.createElement('div');
                        fb.className = 'invalid-feedback';
                        field.after(fb);
                    }
                    fb.textContent = label + ' должно содержать только кириллические буквы, пробел и дефис';
                    valid = false;
                } else {
                    field.classList.remove('is-invalid');
                }
            });

            if (loginField) {
                const val = loginField.value.trim();
                if (!/^[a-zA-Z0-9\-]+$/.test(val)) {
                    loginField.classList.add('is-invalid');
                    let fb = loginField.nextElementSibling;
                    if (!fb || !fb.classList.contains('invalid-feedback')) {
                        fb = document.createElement('div');
                        fb.className = 'invalid-feedback';
                        loginField.after(fb);
                    }
                    fb.textContent = 'Логин должен содержать только латинские буквы, цифры и дефис';
                    valid = false;
                } else {
                    loginField.classList.remove('is-invalid');
                }
            }

            // Rules checkbox
            const rulesBox = regForm.querySelector('[name="rules"]');
            if (rulesBox && !rulesBox.checked) {
                rulesBox.classList.add('is-invalid');
                let fb = rulesBox.closest('.form-check').querySelector('.invalid-feedback');
                if (!fb) {
                    fb = document.createElement('div');
                    fb.className = 'invalid-feedback';
                    rulesBox.closest('.form-check').appendChild(fb);
                }
                fb.textContent = 'Необходимо принять правила регистрации';
                valid = false;
            } else if (rulesBox) {
                rulesBox.classList.remove('is-invalid');
            }

            if (!valid) e.preventDefault();
        });
    }

});
