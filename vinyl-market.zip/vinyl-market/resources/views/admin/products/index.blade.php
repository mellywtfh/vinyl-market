@extends('layouts.app')

@section('content')
<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Товары</h2>
        <a href="{{ route('admin.products.create') }}" class="btn btn-primary">+ Добавить товар</a>
    </div>
    <p><a href="{{ route('admin.dashboard') }}">← Админ панель</a></p>

    @if($products->count() > 0)
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Фото</th>
                    <th>Название</th>
                    <th>Категория</th>
                    <th>Цена</th>
                    <th class="text-center">Количество</th>
                    <th class="text-center">Действия</th>
                </tr>
            </thead>
            <tbody>
                @foreach($products as $product)
                    <tr>
                        <td>{{ $product->id }}</td>
                        <td>
                            @if($product->image_url)
                                <img src="{{ $product->image_url }}"
                                     class="rounded" style="width:50px;height:50px;object-fit:cover;">
                            @else
                                —
                            @endif
                        </td>
                        <td>{{ $product->name }}</td>
                        <td>{{ $product->category->name }}</td>
                        <td>{{ number_format($product->price, 0, '.', ' ') }} ₽</td>
                        <td class="text-center">
                            <span class="badge {{ $product->quantity > 0 ? 'bg-success' : 'bg-danger' }}">
                                {{ $product->quantity }}
                            </span>
                        </td>
                        <td class="text-center">
                            <a href="{{ route('admin.products.edit', $product->id) }}" class="btn btn-sm btn-outline-primary">Изменить</a>
                            <a href="{{ route('admin.products.delete', $product->id) }}" class="btn btn-sm btn-outline-danger"
                               onclick="return confirm('Удалить товар?')">Удалить</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <div class="alert alert-info">Товаров нет. <a href="{{ route('admin.products.create') }}">Добавить</a></div>
    @endif
</div>
@endsection
