@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Редактировать товар</h2>
    <p><a href="{{ route('admin.products') }}">← Список товаров</a></p>

    @if($errors->any())
        <div class="alert alert-danger">
            <ul class="mb-0">@foreach($errors->all() as $e)<li>{{ $e }}</li>@endforeach</ul>
        </div>
    @endif

    <div class="card">
        <div class="card-body">
            <form method="POST" action="{{ route('admin.products.update', $product->id) }}" enctype="multipart/form-data">
                @csrf
                <div class="row g-3">
                    <div class="col-12">
                        <label class="form-label">Название *</label>
                        <input type="text" name="name" class="form-control" value="{{ old('name', $product->name) }}" required>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Описание</label>
                        <textarea name="description" class="form-control" rows="3">{{ old('description', $product->description) }}</textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Категория *</label>
                        <select name="category_id" class="form-select" required>
                            @foreach($categories as $cat)
                                <option value="{{ $cat->id }}" {{ old('category_id', $product->category_id) == $cat->id ? 'selected' : '' }}>
                                    {{ $cat->name }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Цена (₽) *</label>
                        <input type="number" name="price" class="form-control" value="{{ old('price', $product->price) }}" min="0" step="0.01" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Количество *</label>
                        <input type="number" name="quantity" class="form-control" value="{{ old('quantity', $product->quantity) }}" min="0" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Год выпуска</label>
                        <input type="number" name="year" class="form-control" value="{{ old('year', $product->year) }}" min="1990" max="{{ date('Y') }}">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Страна-производитель</label>
                        <input type="text" name="country" class="form-control" value="{{ old('country', $product->country) }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Модель</label>
                        <input type="text" name="model" class="form-control" value="{{ old('model', $product->model) }}">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Фото</label>
                        @if($product->image_url)
                            <div class="mb-1">
                                <img src="{{ $product->image_url }}" style="height:60px;" class="rounded">
                                <small class="text-muted ms-2">текущее фото</small>
                            </div>
                        @endif
                        <input type="file" name="image" class="form-control" accept="image/*">
                    </div>
                </div>
                <div class="mt-3 d-flex gap-2">
                    <button type="submit" class="btn btn-primary">Сохранить</button>
                    <a href="{{ route('admin.products') }}" class="btn btn-outline-secondary">Отмена</a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
