@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-2 fw-bold">Все заказы</h2>
    <p><a href="{{ route('admin.dashboard') }}">← Админ панель</a></p>

    {{-- Фильтр по статусу --}}
    <div class="d-flex gap-2 mb-3 flex-wrap">
        <a href="{{ route('admin.orders') }}"
           class="btn btn-sm {{ $statusFilter == '' ? 'btn-dark' : 'btn-outline-dark' }}">Все</a>
        <a href="{{ route('admin.orders', ['status' => 'pending']) }}"
           class="btn btn-sm {{ $statusFilter == 'pending' ? 'btn-warning' : 'btn-outline-warning' }}">Новые</a>
        <a href="{{ route('admin.orders', ['status' => 'processing']) }}"
           class="btn btn-sm {{ $statusFilter == 'processing' ? 'btn-info' : 'btn-outline-info' }}">В обработке</a>
        <a href="{{ route('admin.orders', ['status' => 'completed']) }}"
           class="btn btn-sm {{ $statusFilter == 'completed' ? 'btn-success' : 'btn-outline-success' }}">Выполненные</a>
        <a href="{{ route('admin.orders', ['status' => 'cancelled']) }}"
           class="btn btn-sm {{ $statusFilter == 'cancelled' ? 'btn-danger' : 'btn-outline-danger' }}">Отменённые</a>
    </div>

    @if($orders->count() > 0)
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Клиент</th>
                    <th>Дата</th>
                    <th class="text-center">Количество товаров</th>
                    <th class="text-end">Сумма</th>
                    <th class="text-center">Статус</th>
                    <th class="text-center">Изменить статус</th>
                </tr>
            </thead>
            <tbody>
                @foreach($orders as $order)
                    <tr>
                        <td>{{ $order->id }}</td>
                        <td>
                            {{ $order->user->surname }} {{ $order->user->name }}<br>
                            <small class="text-muted">{{ $order->user->login }}</small>
                        </td>
                        <td class="small">{{ $order->created_at->format('d.m.Y H:i') }}</td>
                        <td class="text-center">
                            {{ $order->items->sum('quantity') }} шт.
                        </td>
                        <td class="text-end fw-bold">{{ number_format($order->total, 0, '.', ' ') }} ₽</td>
                        <td class="text-center">
                            <span class="badge
                                {{ $order->status == 'completed'  ? 'bg-success'  : '' }}
                                {{ $order->status == 'pending'    ? 'bg-warning text-dark' : '' }}
                                {{ $order->status == 'processing' ? 'bg-info text-dark'   : '' }}
                                {{ $order->status == 'cancelled'  ? 'bg-danger'   : '' }}">
                                {{ $order->status_label }}
                            </span>
                        </td>
                        <td class="text-center">
                            <form method="POST" action="{{ route('admin.orders.status', $order->id) }}" class="d-flex gap-1 justify-content-center">
                                @csrf
                                <select name="status" class="form-select form-select-sm" style="width:auto">
                                    <option value="pending"    {{ $order->status == 'pending'    ? 'selected' : '' }}>В ожидании</option>
                                    <option value="processing" {{ $order->status == 'processing' ? 'selected' : '' }}>В обработке</option>
                                    <option value="completed"  {{ $order->status == 'completed'  ? 'selected' : '' }}>Выполнен</option>
                                    <option value="cancelled"  {{ $order->status == 'cancelled'  ? 'selected' : '' }}>Отменён</option>
                                </select>
                                <button type="submit" class="btn btn-primary btn-sm">OK</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @else
        <div class="alert alert-info">Заказов не найдено</div>
    @endif
</div>
@endsection
