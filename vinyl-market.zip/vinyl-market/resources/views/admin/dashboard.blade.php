@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Админ панель</h2>

    <div class="row g-3 mb-4">
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3>{{ $productsCount }}</h3>
                    <p class="text-muted">Товаров</p>
                    <a href="{{ route('admin.products') }}" class="btn btn-primary btn-sm">Управлять</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3>{{ $categoriesCount }}</h3>
                    <p class="text-muted">Категорий</p>
                    <a href="{{ route('admin.categories') }}" class="btn btn-success btn-sm">Управлять</a>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card text-center">
                <div class="card-body">
                    <h3>{{ $ordersCount }}</h3>
                    <p class="text-muted">Заказов</p>
                    <a href="{{ route('admin.orders') }}" class="btn btn-warning btn-sm">Просмотреть</a>
                </div>
            </div>
        </div>
    </div>

    <div class="d-flex gap-2">
        <a href="{{ route('admin.products.create') }}" class="btn btn-outline-primary">+ Добавить товар</a>
        <a href="{{ route('admin.categories') }}" class="btn btn-outline-success">Категории</a>
        <a href="{{ route('admin.orders') }}" class="btn btn-outline-warning">Все заказы</a>
    </div>
</div>
@endsection
