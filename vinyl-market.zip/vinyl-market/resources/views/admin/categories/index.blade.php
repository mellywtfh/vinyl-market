@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-2">Категории</h2>
    <p><a href="{{ route('admin.dashboard') }}">← Админ панель</a></p>

    <div class="row g-4">
        <div class="col-md-5">
            <div class="card">
                <div class="card-header">Добавить категорию</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('admin.categories.store') }}">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label">Название *</label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                                   value="{{ old('name') }}" placeholder="Например: Смартфоны" required>
                            @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>
                        <button type="submit" class="btn btn-success w-100">Добавить</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-7">
            <table class="table table-bordered">
                <thead class="table-dark">
                    <tr>
                        <th>#</th>
                        <th>Название</th>
                        <th class="text-center">Товаров</th>
                        <th class="text-center">Удалить</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($categories as $cat)
                        <tr>
                            <td>{{ $cat->id }}</td>
                            <td>{{ $cat->name }}</td>
                            <td class="text-center">{{ $cat->products_count }}</td>
                            <td class="text-center">
                                <a href="{{ route('admin.categories.delete', $cat->id) }}"
                                   class="btn btn-danger btn-sm"
                                   onclick="return confirm('Удалить категорию «{{ $cat->name }}»?\nВсе товары этой категории тоже будут удалены!')">
                                    Удалить
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="text-center text-muted">Категорий нет</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
