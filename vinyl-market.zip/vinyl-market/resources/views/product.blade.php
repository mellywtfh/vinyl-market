@extends('layouts.app')

@section('content')
<div class="container">

    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('about') }}">Главная</a></li>
            <li class="breadcrumb-item"><a href="{{ route('catalog') }}">Каталог</a></li>
            <li class="breadcrumb-item active">{{ $product->name }}</li>
        </ol>
    </nav>

    <div class="row g-4">
        {{-- Фото --}}
        <div class="col-md-5 text-center">
            @if($product->image_url)
                <img src="{{ $product->image_url }}"
                     alt="{{ $product->name }}"
                     class="img-fluid border rounded shadow-sm" style="max-height:380px; object-fit:contain;">
            @else
                <div class="bg-light border rounded d-flex align-items-center justify-content-center"
                     style="height:380px;">
                    <span class="text-muted fs-5">Нет фото</span>
                </div>
            @endif
        </div>

        {{-- Инфо --}}
        <div class="col-md-7">
            <p class="text-muted mb-1 text-uppercase small fw-semibold">{{ $product->category->name }}</p>
            <h2 class="fw-bold mb-2">{{ $product->name }}</h2>
            <h3 class="text-primary fw-bold mb-3">{{ number_format($product->price, 0, '.', ' ') }} ₽</h3>

            <p class="fs-6 {{ $product->quantity > 0 ? 'text-success' : 'text-danger' }} fw-semibold">
                {{ $product->quantity > 0 ? 'В наличии: ' . $product->quantity . ' шт.' : 'Нет в наличии' }}
            </p>

            @if($product->description)
                <p class="text-secondary lh-lg">{{ $product->description }}</p>
            @endif

            {{-- Характеристики --}}
            <table class="table table-bordered w-auto mt-3">
                <tbody>
                    @if($product->model)
                        <tr><th>Модель</th><td>{{ $product->model }}</td></tr>
                    @endif
                    @if($product->country)
                        <tr><th>Страна производителя</th><td>{{ $product->country }}</td></tr>
                    @endif
                    @if($product->year)
                        <tr><th>Год выпуска</th><td>{{ $product->year }}</td></tr>
                    @endif
                    <tr><th>Категория</th><td>{{ $product->category->name }}</td></tr>
                </tbody>
            </table>

            {{-- Кнопка --}}
            @auth
                @if($product->quantity > 0)
                    <button class="btn btn-primary add-to-cart-detail" data-id="{{ $product->id }}">
                        В корзину
                    </button>
                    <a href="{{ route('cart') }}" class="btn btn-outline-secondary ms-2">Корзина</a>
                @else
                    <button class="btn btn-secondary" disabled>Нет в наличии</button>
                @endif
            @else
                <a href="{{ route('login') }}" class="btn btn-primary">Войдите, чтобы купить</a>
            @endauth
        </div>
    </div>
</div>

{{-- Toast --}}
<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1080">
    <div id="cartToast" class="toast align-items-center text-bg-success border-0">
        <div class="d-flex">
            <div class="toast-body">Товар добавлен в корзину!</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
    <div id="cartToastError" class="toast align-items-center text-bg-danger border-0 mt-2">
        <div class="d-flex">
            <div class="toast-body" id="cartToastErrorMsg"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>
@endsection
