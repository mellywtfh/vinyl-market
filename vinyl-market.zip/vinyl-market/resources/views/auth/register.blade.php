@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7">
            <h2 class="mb-4">Регистрация</h2>
            <div class="card">
                <div class="card-body">
                    <form method="POST" action="{{ route('register') }}" id="register-form" novalidate>
                        @csrf

                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label">Фамилия <span class="text-danger">*</span></label>
                                <input type="text" name="surname" class="form-control @error('surname') is-invalid @enderror"
                                       value="{{ old('surname') }}" required>
                                @error('surname')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Имя <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control @error('name') is-invalid @enderror"
                                       value="{{ old('name') }}" required>
                                @error('name')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Отчество</label>
                                <input type="text" name="patronymic" class="form-control @error('patronymic') is-invalid @enderror"
                                       value="{{ old('patronymic') }}">
                                @error('patronymic')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                        </div>

                        <div class="mb-3 mt-3">
                            <label class="form-label">Логин <span class="text-danger">*</span></label>
                            <input type="text" name="login" class="form-control @error('login') is-invalid @enderror"
                                   value="{{ old('login') }}" required>
                            <div class="form-text">Только латинские буквы, цифры и дефис</div>
                            @error('login')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror"
                                   value="{{ old('email') }}" required>
                            @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <div class="row g-3 mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Пароль <span class="text-danger">*</span></label>
                                <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" required>
                                <div class="form-text">Минимум 6 символов</div>
                                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Подтверждение пароля <span class="text-danger">*</span></label>
                                <input type="password" name="password_confirmation" class="form-control" required>
                            </div>
                        </div>

                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input @error('rules') is-invalid @enderror"
                                   name="rules" id="rules" value="1">
                            <label class="form-check-label" for="rules">
                                Я согласен с <a href="#" data-bs-toggle="modal" data-bs-target="#rulesModal">правилами регистрации</a> <span class="text-danger">*</span>
                            </label>
                            @error('rules')<div class="invalid-feedback">{{ $message }}</div>@enderror
                        </div>

                        <button type="submit" class="btn btn-primary w-100">Зарегистрироваться</button>
                        <hr>
                        <p class="text-center mb-0">Уже есть аккаунт? <a href="{{ route('login') }}">Войти</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
{{-- Модальное окно с правилами --}}
<div class="modal fade" id="rulesModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Правила регистрации</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body small">
                <p>1. Регистрируясь на сайте , вы соглашаетесь с условиями магазина VinylMarket</p>
                <p>2. Ваши данные обрабатываются в соответствии с законодательством РФ.</p>
                <p>3. Запрещается регистрация нескольких аккаунтов одним пользователем.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary btn-sm" data-bs-dismiss="modal">Понятно</button>
            </div>
        </div>
    </div>
</div>
@endsection
