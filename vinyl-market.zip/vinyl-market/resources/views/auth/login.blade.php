@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <h2 class="mb-4 fw-bold">Вход</h2>

            <div class="card shadow-sm">
                <div class="card-body p-4">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Логин</label>
                            <input type="text" name="login" class="form-control form-control-lg @error('login') is-invalid @enderror"
                                   value="{{ old('login') }}" required autofocus>
                            @error('login')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-semibold">Пароль</label>
                            <input type="password" name="password" class="form-control form-control-lg @error('password') is-invalid @enderror" required>
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" name="remember" id="remember">
                            <label class="form-check-label" for="remember">Запомнить меня</label>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg w-100">Войти</button>
                        <hr>
                        <p class="text-center mb-0">Нет аккаунта? <a href="{{ route('register') }}">Зарегистрироваться</a></p>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
