@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4 fw-bold">Где нас найти?</h2>
    <div class="row g-4">
        <div class="col-md-8">
            <div class="border rounded overflow-hidden shadow-sm">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2245.0!2d37.617!3d55.755!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zTW9zY293!5e0!3m2!1sru!2sru!4v1680000000000"
                    width="100%" height="420" style="border:0;" allowfullscreen="" loading="lazy">
                </iframe>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card shadow-sm h-100">
                <div class="card-body">
                    <h5 class="card-title fw-bold mb-3">Контакты</h5>
                    <hr>
                    <p class="mb-3">
                        <span class="text-muted small text-uppercase fw-semibold">Адрес</span><br>
                        <span class="fs-6">г. Москва,Большой Афанасьевский пер., 35/37 с4</span>
                    </p>
                    <p class="mb-3">
                        <span class="text-muted small text-uppercase fw-semibold">Телефон</span><br>
                        <a href="tel:+74951234567" class="fs-6 text-decoration-none">+7 495 690-06-90</a>
                    </p>
                    <p class="mb-3">
                        <span class="text-muted small text-uppercase fw-semibold">Email</span><br>
                        <a href="mailto:info@technomarket.ru" class="fs-6 text-decoration-none">trade@vinyl.ru</a>
                    </p>
                    <p class="mb-0">
                        <span class="text-muted small text-uppercase fw-semibold">Режим работы</span><br>
                        <span class="fs-6">Ежедневно с 12.00 до 21.00</span>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
