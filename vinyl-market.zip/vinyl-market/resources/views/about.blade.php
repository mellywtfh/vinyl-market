@extends('layouts.app')

@section('content')
<div class="container">

    {{-- Логотип и девиз --}}
    <div class="text-center my-5">
        <h1 class="display-4 fw-bold">Магазин виниловых пластинок</h1>
        <p class="fs-4 text-muted fst-italic">«Живой звук твоего винила»</p>
        <hr class="w-25 mx-auto my-3">
        <p class="lead">Широкий выбор виниловых пластинок для настоящих ценителей качественного звука. В каталоге — классика рока, джаз, поп, электронная музыка.</p>
        <a href="{{ route('catalog') }}" class="btn btn-primary btn-lg mt-2">Перейти в каталог</a>
    </div>

    {{-- Слайдер «Новинки компании» --}}
    @if($latestProducts->count() > 0)
        <h4 class="mb-3 fw-bold">Новинки</h4>
        <div id="slider" class="carousel slide mb-5" data-bs-ride="carousel">
            <div class="carousel-indicators">
                @foreach($latestProducts as $product)
                    <button type="button" data-bs-target="#slider"
                            data-bs-slide-to="{{ $loop->index }}"
                            class="{{ $loop->first ? 'active' : '' }}"
                            aria-current="{{ $loop->first ? 'true' : 'false' }}"></button>
                @endforeach
            </div>

            <div class="carousel-inner rounded shadow-sm" style="background:#f8f9fa;">
                @foreach($latestProducts as $product)
                    <div class="carousel-item {{ $loop->first ? 'active' : '' }}">
                        <div class="row align-items-center g-0" style="min-height:340px;">
                            <div class="col-md-5 text-center p-4">
                                @if($product->image_url)
                                    <img src="{{ $product->image_url }}"
                                         alt="{{ $product->name }}"
                                         class="img-fluid rounded"
                                         style="max-height:260px; object-fit:contain;">
                                @endif
                            </div>
                            <div class="col-md-7 p-4 p-md-5">
                                <span class="badge bg-primary mb-2">{{ $product->category->name }}</span>
                                <h3 class="fw-bold">{{ $product->name }}</h3>
                                @if($product->description)
                                    <p class="text-muted">{{ Str::limit($product->description, 120) }}</p>
                                @endif
                                <p class="fs-3 fw-bold text-primary mb-3">{{ number_format($product->price, 0, '.', ' ') }} ₽</p>
                                <a href="{{ route('product', $product->id) }}" class="btn btn-outline-primary">Подробнее →</a>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>

            <button class="carousel-control-prev" type="button" data-bs-target="#slider" data-bs-slide="prev">
                <span class="carousel-control-prev-icon"></span>
                <span class="visually-hidden">Назад</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#slider" data-bs-slide="next">
                <span class="carousel-control-next-icon"></span>
                <span class="visually-hidden">Вперёд</span>
            </button>
        </div>
    @endif

</div>
@endsection
