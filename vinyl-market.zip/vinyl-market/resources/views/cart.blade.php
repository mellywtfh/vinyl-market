@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Корзина</h2>

    @if(count($products) > 0)
        <div class="row g-4">
            <div class="col-lg-8">
                <table class="table table-bordered align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Товар</th>
                            <th class="text-center">Цена</th>
                            <th class="text-center">Количество</th>
                            <th class="text-center">Сумма</th>
                            <th class="text-center">Удалить</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($products as $item)
                            <tr id="cart-row-{{ $item['product']->id }}">
                                <td>
                                    @if($item['product']->image_url)
                                        <img src="{{ $item['product']->image_url }}"
                                             alt="" style="width:50px;height:50px;object-fit:cover;" class="rounded me-2">
                                    @endif
                                    <a href="{{ route('product', $item['product']->id) }}">{{ $item['product']->name }}</a>
                                </td>
                                <td class="text-center">{{ number_format($item['product']->price, 0, '.', ' ') }} ₽</td>
                                <td class="text-center">
                                    <div class="d-flex align-items-center justify-content-center gap-2">
                                        <button class="btn btn-outline-secondary btn-sm cart-qty-btn"
                                                data-id="{{ $item['product']->id }}" data-action="decrease">−</button>
                                        <span id="qty-{{ $item['product']->id }}">{{ $item['quantity'] }}</span>
                                        <button class="btn btn-outline-secondary btn-sm cart-qty-btn"
                                                data-id="{{ $item['product']->id }}" data-action="increase">+</button>
                                    </div>
                                </td>
                                <td class="text-center" id="subtotal-{{ $item['product']->id }}">
                                    {{ number_format($item['subtotal'], 0, '.', ' ') }} ₽
                                </td>
                                <td class="text-center">
                                    <a href="{{ route('cart.remove', $item['product']->id) }}"
                                       class="btn btn-danger btn-sm"
                                       onclick="return confirm('Удалить?')">✕</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>

                <div class="d-flex justify-content-between">
                    <a href="{{ route('catalog') }}" class="btn btn-outline-secondary">← Продолжить покупки</a>
                    <a href="{{ route('cart.clear') }}" class="btn btn-outline-danger"
                       onclick="return confirm('Очистить корзину?')">Очистить корзину</a>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Итого</h5>
                        <p>Товаров: {{ array_sum(array_column($products, 'quantity')) }} шт.</p>
                        <h4 class="text-primary" id="cart-total">{{ number_format($total, 0, '.', ' ') }} ₽</h4>
                        <a href="{{ route('orders.create') }}" class="btn btn-primary w-100 mt-2">Оформить заказ</a>
                    </div>
                </div>
            </div>
        </div>
    @else
        <div class="alert alert-info">
            Корзина пуста. <a href="{{ route('catalog') }}">Перейти в каталог</a>
        </div>
    @endif
</div>

<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1080">
    <div id="cartErrorToast" class="toast align-items-center text-bg-danger border-0">
        <div class="d-flex">
            <div class="toast-body" id="cartErrorMsg"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>
@endsection
