@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4 fw-bold">Каталог</h2>

    {{-- Фильтры --}}
    <form method="GET" action="{{ route('catalog') }}" class="row g-2 mb-4">
        <div class="col-md-4">
            <select name="category" class="form-select" onchange="this.form.submit()">
                <option value="">Все категории</option>
                @foreach($categories as $cat)
                    <option value="{{ $cat->id }}" {{ request('category') == $cat->id ? 'selected' : '' }}>
                        {{ $cat->name }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-md-4">
            <select name="sort" class="form-select" onchange="this.form.submit()">
                <option value="newest"     {{ $sort == 'newest'     ? 'selected' : '' }}>Сначала новые</option>
                <option value="price_asc"  {{ $sort == 'price_asc'  ? 'selected' : '' }}>Цена: по возрастанию</option>
                <option value="price_desc" {{ $sort == 'price_desc' ? 'selected' : '' }}>Цена: по убыванию</option>
                <option value="name"       {{ $sort == 'name'       ? 'selected' : '' }}>По наименованию</option>
                <option value="year"       {{ $sort == 'year'       ? 'selected' : '' }}>По году выпуска</option>
            </select>
        </div>
        <div class="col-md-2">
            @if(request('category') || request('sort'))
                <a href="{{ route('catalog') }}" class="btn btn-outline-secondary w-100">Сбросить</a>
            @endif
        </div>
    </form>

    {{-- Товары --}}
    @if($products->count() > 0)
        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-3">
            @foreach($products as $product)
                <div class="col">
                    <div class="card h-100">
                        <a href="{{ route('product', $product->id) }}">
                            @if($product->image_url)
                                <img src="{{ $product->image_url }}"
                                     class="card-img-top" alt="{{ $product->name }}"
                                     style="height:180px; object-fit:cover;">
                            @else
                                <div class="bg-light d-flex align-items-center justify-content-center"
                                     style="height:180px;">
                                    <span class="text-muted">Нет фото</span>
                                </div>
                            @endif
                        </a>
                        <div class="card-body d-flex flex-column">
                            <p class="text-muted small mb-1">{{ $product->category->name }}</p>
                            <h6 class="card-title fs-6 fw-semibold">
                                <a href="{{ route('product', $product->id) }}" class="text-decoration-none text-dark">
                                    {{ $product->name }}
                                </a>
                            </h6>
                            <p class="fw-bold text-primary fs-5 mt-auto mb-1">{{ number_format($product->price, 0, '.', ' ') }} ₽</p>
                            <p class="small {{ $product->quantity > 0 ? 'text-success' : 'text-danger' }} mb-2">
                                {{ $product->quantity > 0 ? 'В наличии' : 'Нет в наличии' }}
                            </p>
                            <div class="d-flex gap-1">
                                <a href="{{ route('product', $product->id) }}" class="btn btn-outline-primary btn-sm flex-grow-1">Подробнее</a>
                                @auth
                                    @if($product->quantity > 0)
                                        <button class="btn btn-primary btn-sm add-to-cart" data-id="{{ $product->id }}">В корзину</button>
                                    @endif
                                @endauth
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    @else
        <div class="alert alert-info">Товары не найдены. <a href="{{ route('catalog') }}">Сбросить фильтры</a></div>
    @endif
</div>

{{-- Toast --}}
<div class="position-fixed bottom-0 end-0 p-3" style="z-index:1080">
    <div id="cartToast" class="toast align-items-center text-bg-success border-0">
        <div class="d-flex">
            <div class="toast-body">Товар добавлен в корзину!</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
    <div id="cartToastError" class="toast align-items-center text-bg-danger border-0 mt-2">
        <div class="d-flex">
            <div class="toast-body" id="cartToastErrorMsg"></div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    </div>
</div>
@endsection
