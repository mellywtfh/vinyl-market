@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Оформление заказа</h2>

    <div class="row g-4">
        <div class="col-md-7">
            <h5>Состав заказа</h5>
            <table class="table table-bordered">
                <thead class="table-light">
                    <tr>
                        <th>Товар</th>
                        <th class="text-center">Количество</th>
                        <th class="text-end">Сумма</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($products as $item)
                        <tr>
                            <td>{{ $item['product']->name }}</td>
                            <td class="text-center">{{ $item['quantity'] }}</td>
                            <td class="text-end">{{ number_format($item['subtotal'], 0, '.', ' ') }} ₽</td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr class="fw-bold">
                        <td colspan="2" class="text-end">Итого:</td>
                        <td class="text-end text-primary fs-5">{{ number_format($total, 0, '.', ' ') }} ₽</td>
                    </tr>
                </tfoot>
            </table>
        </div>

        <div class="col-md-5">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Подтверждение</h5>
                    <p class="text-muted small">Введите ваш пароль для подтверждения заказа</p>

                    <div id="order-error" class="alert alert-danger d-none"></div>

                    <div class="mb-3">
                        <label class="form-label">Пароль</label>
                        <input type="password" class="form-control" id="confirm-password" placeholder="Ваш пароль">
                    </div>
                    <button class="btn btn-primary w-100" id="btn-place-order">Сформировать заказ</button>
                    <a href="{{ route('cart') }}" class="btn btn-outline-secondary w-100 mt-2">← Вернуться в корзину</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('btn-place-order').addEventListener('click', function () {
    const password = document.getElementById('confirm-password').value;
    const errorDiv = document.getElementById('order-error');
    errorDiv.classList.add('d-none');

    if (!password) {
        errorDiv.textContent = 'Введите пароль';
        errorDiv.classList.remove('d-none');
        return;
    }

    const btn = this;
    btn.disabled = true;
    btn.textContent = 'Оформляем...';

    fetch('{{ route("orders.store") }}', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content,
        },
        body: JSON.stringify({ password })
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            window.location.href = data.redirect;
        } else {
            errorDiv.textContent = data.error || 'Ошибка';
            errorDiv.classList.remove('d-none');
            btn.disabled = false;
            btn.textContent = 'Сформировать заказ';
        }
    });
});
</script>
@endsection
