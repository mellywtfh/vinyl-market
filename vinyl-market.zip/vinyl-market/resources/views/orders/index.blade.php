@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4 fw-bold">Мои заказы</h2>

    @if($orders->count() > 0)
        @foreach($orders as $order)
            <div class="card mb-3 shadow-sm">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-semibold">Заказ #{{ $order->id }} — {{ $order->created_at->format('d.m.Y H:i') }}</span>
                    <div class="d-flex align-items-center gap-2">
                        @if($order->status == 'pending')
                            <a href="{{ route('orders.destroy', $order->id) }}"
                               class="btn btn-outline-danger btn-sm"
                               onclick="return confirm('Удалить заказ #{{ $order->id }}?')">Удалить</a>
                        @endif
                        <span class="badge
                            {{ $order->status == 'completed'  ? 'bg-success'  : '' }}
                            {{ $order->status == 'pending'    ? 'bg-warning text-dark'  : '' }}
                            {{ $order->status == 'processing' ? 'bg-info text-dark'    : '' }}
                            {{ $order->status == 'cancelled'  ? 'bg-danger'   : '' }}">
                            {{ $order->status_label }}
                        </span>
                    </div>
                </div>
                <div class="card-body p-0">
                    <table class="table table-sm mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>Товар</th>
                                <th class="text-center">Количество</th>
                                <th class="text-end">Цена</th>
                                <th class="text-end">Сумма</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($order->items as $item)
                                <tr>
                                    <td>{{ $item->product ? $item->product->name : 'Удалён' }}</td>
                                    <td class="text-center">{{ $item->quantity }}</td>
                                    <td class="text-end">{{ number_format($item->price, 0, '.', ' ') }} ₽</td>
                                    <td class="text-end">{{ number_format($item->price * $item->quantity, 0, '.', ' ') }} ₽</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr class="fw-bold">
                                <td colspan="3" class="text-end">Итого:</td>
                                <td class="text-end text-primary">{{ number_format($order->total, 0, '.', ' ') }} ₽</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        @endforeach
    @else
        <div class="alert alert-info">
            У вас пока нет заказов. <a href="{{ route('catalog') }}">Перейти в каталог</a>
        </div>
    @endif
</div>
@endsection
