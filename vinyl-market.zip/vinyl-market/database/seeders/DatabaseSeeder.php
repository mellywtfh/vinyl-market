<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use App\Models\User;
use App\Models\Category;
use App\Models\Product;

class DatabaseSeeder extends Seeder
{
    public function run()
    {
        // Admin
        User::create([
            'name'       => 'Администратор',
            'surname'    => 'Системный',
            'patronymic' => null,
            'login'      => 'admin',
            'email'      => 'admin@technomarket.ru',
            'password'   => Hash::make('admin11'),
            'role'       => 'admin',
        ]);

        // Test client
        User::create([
            'name'       => 'Иван',
            'surname'    => 'Иванов',
            'patronymic' => 'Иванович',
            'login'      => 'ivanov',
            'email'      => 'ivanov@mail.ru',
            'password'   => Hash::make('password123'),
            'role'       => 'client',
        ]);

        // Categories
        $cats = ['Смартфоны', 'Ноутбуки', 'Планшеты', 'Телевизоры', 'Аксессуары'];
        $categoryIds = [];
        foreach ($cats as $name) {
            $cat = Category::create(['name' => $name]);
            $categoryIds[$name] = $cat->id;
        }

        // Products
        $products = [
            [
                'name' => 'Samsung Galaxy S24 Ultra',
                'description' => 'Флагманский смартфон Samsung с 200 Мп камерой и встроенным S Pen. Экран Dynamic AMOLED 2X 6.8" 120 Гц.',
                'price' => 114990, 'quantity' => 15, 'year' => 2024,
                'country' => 'Южная Корея', 'model' => 'SM-S928B',
                'image' => 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=400&q=80',
                'category_id' => $categoryIds['Смартфоны'],
            ],
            [
                'name' => 'Apple iPhone 15 Pro Max',
                'description' => 'Смартфон Apple с чипом A17 Pro, 48 Мп камерой и корпусом из титана. Экран Super Retina XDR 6.7" 120 Гц.',
                'price' => 129990, 'quantity' => 10, 'year' => 2023,
                'country' => 'США', 'model' => 'MQAF3',
                'image' => 'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=400&q=80',
                'category_id' => $categoryIds['Смартфоны'],
            ],
            [
                'name' => 'Xiaomi 14 Pro',
                'description' => 'Смартфон с камерой Leica, Snapdragon 8 Gen 3 и зарядкой 120 Вт. AMOLED 6.73" 2K+.',
                'price' => 74990, 'quantity' => 20, 'year' => 2024,
                'country' => 'Китай', 'model' => '24112RKG8G',
                'image' => 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400&q=80',
                'category_id' => $categoryIds['Смартфоны'],
            ],
            [
                'name' => 'Apple MacBook Pro 14" M3 Pro',
                'description' => 'Профессиональный ноутбук на чипе M3 Pro с дисплеем Liquid Retina XDR, до 18 часов работы.',
                'price' => 199990, 'quantity' => 8, 'year' => 2023,
                'country' => 'США', 'model' => 'MRX33',
                'image' => 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=400&q=80',
                'category_id' => $categoryIds['Ноутбуки'],
            ],
            [
                'name' => 'ASUS ROG Zephyrus G14',
                'description' => 'Игровой ноутбук с AMD Ryzen 9, GeForce RTX 4060 и OLED 120 Гц. Мощность и компактность.',
                'price' => 119990, 'quantity' => 5, 'year' => 2024,
                'country' => 'Тайвань', 'model' => 'GA403UV',
                'image' => 'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=400&q=80',
                'category_id' => $categoryIds['Ноутбуки'],
            ],
            [
                'name' => 'Lenovo ThinkPad X1 Carbon Gen 12',
                'description' => 'Бизнес-ноутбук с Intel Core Ultra 7, весом 1.12 кг и дисплеем 2.8K IPS.',
                'price' => 149990, 'quantity' => 6, 'year' => 2024,
                'country' => 'Китай', 'model' => '21KC0033RK',
                'image' => 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=400&q=80',
                'category_id' => $categoryIds['Ноутбуки'],
            ],
            [
                'name' => 'Apple iPad Pro 12.9" M2',
                'description' => 'Профессиональный планшет на чипе M2 с дисплеем Liquid Retina XDR, поддержкой Apple Pencil.',
                'price' => 109990, 'quantity' => 12, 'year' => 2022,
                'country' => 'США', 'model' => 'MNXQ3',
                'image' => 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400&q=80',
                'category_id' => $categoryIds['Планшеты'],
            ],
            [
                'name' => 'Samsung Galaxy Tab S9 Ultra',
                'description' => 'Планшет с экраном Dynamic AMOLED 14.6", Snapdragon 8 Gen 2 и S Pen в комплекте.',
                'price' => 89990, 'quantity' => 9, 'year' => 2023,
                'country' => 'Южная Корея', 'model' => 'SM-X916B',
                'image' => 'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=400&q=80',
                'category_id' => $categoryIds['Планшеты'],
            ],
            [
                'name' => 'Samsung QLED 4K 65" QN90C',
                'description' => 'Телевизор с Neo QLED, 4K процессором и 120 Гц. HDR10+ и Dolby Atmos.',
                'price' => 119990, 'quantity' => 4, 'year' => 2023,
                'country' => 'Южная Корея', 'model' => 'QE65QN90C',
                'image' => 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=400&q=80',
                'category_id' => $categoryIds['Телевизоры'],
            ],
            [
                'name' => 'LG OLED evo C3 55"',
                'description' => 'OLED телевизор с процессором α9 Gen6 AI и поддержкой 4K/120 Гц. Идеал для кино и игр.',
                'price' => 84990, 'quantity' => 7, 'year' => 2023,
                'country' => 'Южная Корея', 'model' => 'OLED55C3RLA',
                'image' => 'https://images.unsplash.com/photo-1601944179066-29786cb9d32a?w=400&q=80',
                'category_id' => $categoryIds['Телевизоры'],
            ],
            [
                'name' => 'Apple AirPods Pro 2',
                'description' => 'Наушники с активным шумоподавлением, Adaptive Audio и до 30 часов работы с кейсом.',
                'price' => 24990, 'quantity' => 30, 'year' => 2023,
                'country' => 'США', 'model' => 'MTJV3',
                'image' => 'https://images.unsplash.com/photo-1572536147248-ac59a8abfa4b?w=400&q=80',
                'category_id' => $categoryIds['Аксессуары'],
            ],
            [
                'name' => 'Samsung Galaxy Watch 6 Classic 47mm',
                'description' => 'Умные часы с вращающимся кольцом управления, датчиком ЭКГ и GPS.',
                'price' => 34990, 'quantity' => 18, 'year' => 2023,
                'country' => 'Южная Корея', 'model' => 'SM-R960NZSACIS',
                'image' => 'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=400&q=80',
                'category_id' => $categoryIds['Аксессуары'],
            ],
        ];

        foreach ($products as $p) {
            Product::create($p);
        }
    }
}
