<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = ['user_id', 'status', 'total'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }

    public function getStatusLabelAttribute()
    {
        $labels = [
            'pending'    => 'Ожидает',
            'processing' => 'В обработке',
            'completed'  => 'Выполнен',
            'cancelled'  => 'Отменён',
        ];
        return $labels[$this->status] ?? $this->status;
    }
}
