<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;

class CartController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $cart = session()->get('cart', []);
        $products = [];
        $total = 0;
        foreach ($cart as $productId => $item) {
            $product = Product::find($productId);
            if ($product) {
                $products[] = [
                    'product'  => $product,
                    'quantity' => $item['quantity'],
                    'subtotal' => $product->price * $item['quantity'],
                ];
                $total += $product->price * $item['quantity'];
            }
        }
        return view('cart', compact('products', 'total'));
    }

    public function add(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $cart = session()->get('cart', []);
        $currentQty = isset($cart[$id]) ? $cart[$id]['quantity'] : 0;

        if ($currentQty >= $product->quantity) {
            return response()->json(['error' => 'Нельзя добавить больше, чем есть в наличии'], 400);
        }

        $cart[$id] = ['quantity' => $currentQty + 1];
        session()->put('cart', $cart);

        $cartCount = array_sum(array_column($cart, 'quantity'));
        return response()->json(['success' => true, 'cart_count' => $cartCount]);
    }

    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);
        $cart = session()->get('cart', []);
        $action = $request->get('action');

        if (!isset($cart[$id])) {
            return response()->json(['error' => 'Товар не найден в корзине'], 400);
        }

        if ($action === 'increase') {
            if ($cart[$id]['quantity'] >= $product->quantity) {
                return response()->json(['error' => 'Нельзя добавить больше, чем есть в наличии'], 400);
            }
            $cart[$id]['quantity']++;
        } elseif ($action === 'decrease') {
            $cart[$id]['quantity']--;
            if ($cart[$id]['quantity'] <= 0) {
                unset($cart[$id]);
            }
        }

        session()->put('cart', $cart);
        $cartCount = array_sum(array_column($cart, 'quantity'));
        return response()->json(['success' => true, 'cart_count' => $cartCount]);
    }

    public function remove($id)
    {
        $cart = session()->get('cart', []);
        unset($cart[$id]);
        session()->put('cart', $cart);
        return redirect()->route('cart')->with('success', 'Товар удалён из корзины');
    }

    public function clear()
    {
        session()->forget('cart');
        return redirect()->route('cart');
    }
}
