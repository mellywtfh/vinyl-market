<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use App\Models\Category;

class WebController extends Controller
{
    public function about()
    {
        $latestProducts = Product::where('quantity', '>', 0)
            ->orderBy('created_at', 'desc')
            ->limit(5)
            ->get();
        return view('about', compact('latestProducts'));
    }

    public function catalog(Request $request)
    {
        $categories = Category::all();
        $query = Product::with('category')->where('quantity', '>', 0);

        if ($request->category) {
            $query->where('category_id', $request->category);
        }

        $sort = $request->get('sort', 'newest');
        switch ($sort) {
            case 'price_asc':
                $query->orderBy('price', 'asc');
                break;
            case 'price_desc':
                $query->orderBy('price', 'desc');
                break;
            case 'name':
                $query->orderBy('name', 'asc');
                break;
            case 'year':
                $query->orderBy('year', 'desc');
                break;
            default:
                $query->orderBy('created_at', 'desc');
        }

        $products = $query->get();
        return view('catalog', compact('products', 'categories', 'sort'));
    }

    public function product($id)
    {
        $product = Product::with('category')->findOrFail($id);
        return view('product', compact('product'));
    }

    public function contacts()
    {
        return view('contacts');
    }
}
