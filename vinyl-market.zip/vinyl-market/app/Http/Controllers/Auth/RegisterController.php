<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Models\User;
use Illuminate\Foundation\Auth\RegistersUsers;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class RegisterController extends Controller
{
    use RegistersUsers;

    protected $redirectTo = '/about';

    public function __construct()
    {
        $this->middleware('guest');
    }

    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name'      => ['required', 'string', 'regex:/^[а-яёА-ЯЁ\s\-]+$/u', 'max:255'],
            'surname'   => ['required', 'string', 'regex:/^[а-яёА-ЯЁ\s\-]+$/u', 'max:255'],
            'patronymic'=> ['nullable', 'string', 'regex:/^[а-яёА-ЯЁ\s\-]*$/u', 'max:255'],
            'login'     => ['required', 'string', 'regex:/^[a-zA-Z0-9\-]+$/', 'max:255', 'unique:users'],
            'email'     => ['required', 'string', 'email', 'max:255', 'unique:users'],
            'password'  => ['required', 'string', 'min:6', 'confirmed'],
            'rules'     => ['required', 'accepted'],
        ], [
            'name.required'      => 'Имя обязательно',
            'name.regex'         => 'Имя должно содержать только кириллические буквы, пробел и дефис',
            'surname.required'   => 'Фамилия обязательна',
            'surname.regex'      => 'Фамилия должна содержать только кириллические буквы, пробел и дефис',
            'patronymic.regex'   => 'Отчество должно содержать только кириллические буквы, пробел и дефис',
            'login.required'     => 'Логин обязателен',
            'login.regex'        => 'Логин должен содержать только латинские буквы, цифры и дефис',
            'login.unique'       => 'Этот логин уже занят',
            'email.required'     => 'Email обязателен',
            'email.unique'       => 'Этот email уже используется',
            'password.required'  => 'Пароль обязателен',
            'password.min'       => 'Пароль должен содержать не менее 6 символов',
            'password.confirmed' => 'Пароли не совпадают',
            'rules.required'     => 'Необходимо принять правила регистрации',
            'rules.accepted'     => 'Необходимо принять правила регистрации',
        ]);
    }

    protected function create(array $data)
    {
        return User::create([
            'name'       => $data['name'],
            'surname'    => $data['surname'],
            'patronymic' => $data['patronymic'] ?? null,
            'login'      => $data['login'],
            'email'      => $data['email'],
            'password'   => Hash::make($data['password']),
            'role'       => 'client',
        ]);
    }
}
