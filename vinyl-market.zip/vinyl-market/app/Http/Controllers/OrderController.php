<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $orders = Auth::user()->orders()->with('items.product')->orderBy('created_at', 'desc')->get();
        return view('orders.index', compact('orders'));
    }

    public function create()
    {
        $cart = session()->get('cart', []);
        if (empty($cart)) {
            return redirect()->route('cart')->with('error', 'Корзина пуста');
        }

        $products = [];
        $total = 0;
        foreach ($cart as $productId => $item) {
            $product = Product::find($productId);
            if ($product) {
                $products[] = [
                    'product'  => $product,
                    'quantity' => $item['quantity'],
                    'subtotal' => $product->price * $item['quantity'],
                ];
                $total += $product->price * $item['quantity'];
            }
        }
        return view('orders.create', compact('products', 'total'));
    }

    public function store(Request $request)
    {
        $request->validate(['password' => 'required']);

        if (!Hash::check($request->password, Auth::user()->password)) {
            return response()->json(['error' => 'Неверный пароль'], 400);
        }

        $cart = session()->get('cart', []);
        if (empty($cart)) {
            return response()->json(['error' => 'Корзина пуста'], 400);
        }

        $total = 0;
        foreach ($cart as $productId => $item) {
            $product = Product::find($productId);
            if ($product) {
                $total += $product->price * $item['quantity'];
            }
        }

        $order = Order::create([
            'user_id' => Auth::id(),
            'status'  => 'pending',
            'total'   => $total,
        ]);

        foreach ($cart as $productId => $item) {
            $product = Product::find($productId);
            if ($product) {
                OrderItem::create([
                    'order_id'   => $order->id,
                    'product_id' => $productId,
                    'quantity'   => $item['quantity'],
                    'price'      => $product->price,
                ]);
                $product->decrement('quantity', $item['quantity']);
            }
        }

        session()->forget('cart');
        return response()->json(['success' => true, 'redirect' => route('orders.index')]);
    }

    public function destroy($id)
    {
        $order = Order::where('id', $id)->where('user_id', Auth::id())->where('status', 'pending')->firstOrFail();
        $order->items()->delete();
        $order->delete();
        return redirect()->route('orders.index')->with('success', 'Заказ удалён');
    }
}
