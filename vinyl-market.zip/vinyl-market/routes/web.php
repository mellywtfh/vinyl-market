<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\WebController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AdminController;

// Redirect root to about
Route::get('/', function () {
    return redirect('/about');
});

// Public pages
Route::get('/about',        [WebController::class, 'about'])->name('about');
Route::get('/catalog',      [WebController::class, 'catalog'])->name('catalog');
Route::get('/product/{id}', [WebController::class, 'product'])->name('product');
Route::get('/contacts',     [WebController::class, 'contacts'])->name('contacts');

// Auth routes
Auth::routes();

// Cart (auth required)
Route::get('/cart',              [CartController::class, 'index'])->name('cart');
Route::post('/cart/add/{id}',    [CartController::class, 'add'])->name('cart.add');
Route::post('/cart/update/{id}', [CartController::class, 'update'])->name('cart.update');
Route::get('/cart/remove/{id}',  [CartController::class, 'remove'])->name('cart.remove');
Route::get('/cart/clear',        [CartController::class, 'clear'])->name('cart.clear');

// Orders (auth required)
Route::get('/orders',        [OrderController::class, 'index'])->name('orders.index');
Route::get('/orders/create', [OrderController::class, 'create'])->name('orders.create');
Route::post('/orders',             [OrderController::class, 'store'])->name('orders.store');
Route::get('/orders/{id}/delete',  [OrderController::class, 'destroy'])->name('orders.destroy');

// Admin panel
Route::prefix('admin')->name('admin.')->middleware(['auth', 'admin'])->group(function () {
    Route::get('/',                       [AdminController::class, 'dashboard'])->name('dashboard');

    // Products
    Route::get('/products',               [AdminController::class, 'products'])->name('products');
    Route::get('/products/create',        [AdminController::class, 'productCreate'])->name('products.create');
    Route::post('/products',              [AdminController::class, 'productStore'])->name('products.store');
    Route::get('/products/{id}/edit',     [AdminController::class, 'productEdit'])->name('products.edit');
    Route::post('/products/{id}',         [AdminController::class, 'productUpdate'])->name('products.update');
    Route::get('/products/{id}/delete',   [AdminController::class, 'productDelete'])->name('products.delete');

    // Categories
    Route::get('/categories',             [AdminController::class, 'categories'])->name('categories');
    Route::post('/categories',            [AdminController::class, 'categoryStore'])->name('categories.store');
    Route::get('/categories/{id}/delete', [AdminController::class, 'categoryDelete'])->name('categories.delete');

    // Orders
    Route::get('/orders',                 [AdminController::class, 'orders'])->name('orders');
    Route::post('/orders/{id}/status',    [AdminController::class, 'orderUpdateStatus'])->name('orders.status');
});
